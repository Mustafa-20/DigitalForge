
# DigitalForge

نسخة تجريبية من موقع DigitalForge - توليد منتجات رقمية جاهزة للتحميل والبيع.
يدعم العربية والإنجليزية، تسجيل مبسط، تجربة مجانية (3 منتجات)، ومشاركة وتحميل PDF.
الدفع مهيأ عبر PayPal إلى: gharatimustafa@gmail.com

## تشغيل محلي (أو على Replit / Vercel)

1. ثبت الاعتماديات:
   ```bash
   npm install
   ```
2. تشغيل الخادم:
   ```bash
   npm start
   ```
3. افتح المتصفح واذهب إلى `http://localhost:3000/`

## نشر على GitHub + Vercel
- ارفع الملفات إلى GitHub ثم اربط المشروع بـ Vercel. Vercel سيعمل تلقائيًا.

